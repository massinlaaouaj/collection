ES

El archivo "dfilters", debe copiarlo a la ruta C:\Users\<nombre_usuario>\AppData\Roaming\Wireshark\ haga la sustitución del archivo, o una copia del antiguo antes de pegarlo.

EN

The file "dfilters", you must copy it to the path C:\Users\<user_name>\AppData\Roaming\Wireshark\ make the replacement of the file, or a copy of the old one before pasting it.